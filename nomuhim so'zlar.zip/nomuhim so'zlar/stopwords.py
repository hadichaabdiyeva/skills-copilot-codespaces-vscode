import string
import re

def read_stopwords(stopwords_filename):
    stopwords = set()  
    try:
        with open(stopwords_filename, 'r', encoding='utf-8') as file:
            for line in file:
                line = line.strip()  
                line = re.sub(r'[^a-zA-Zа-яА-ЯёЁ\s]', '', line) 
                
                if line:  
                    words = line.split()  
                    for word in words:
                        word = word.lower() 
                        stopwords.add(word)  
    except FileNotFoundError:
        print(f"Stopwordlar fayli topilmadi: {stopwords_filename}")
    except Exception as e:
        print(f"Xatolik yuz berdi: {str(e)}")
    return stopwords

def read_and_process_file(input_filename, output_filename, stopwords):
    stopword_count = {} 
    total_stopwords = 0  
    
 
    all_punctuation = string.punctuation + '–-' 
    all_punctuation += '0123456789'
    all_punctuation += "\"'“”"
    
    try:
        with open(input_filename, 'r', encoding='utf-8') as file:
            for line in file:
                line = line.strip()  
                
                if line.startswith('“') and line.endswith('”'):
                    line = line[1:-1]  
                
            
                line = re.sub(r'(\w)-(\w)', r'\1 \2', line)
                
                line = line.translate(str.maketrans('', '', all_punctuation))
                words = line.split()  
                
                for word in words:
                    word = word.lower()  
                    
                    if word in stopwords:
                        total_stopwords += 1  
                        if word in stopword_count:
                            stopword_count[word] += 1
                        else:
                            stopword_count[word] = 1
        
       
        with open(output_filename, 'w', encoding='utf-8') as output_file:
            for word, count in stopword_count.items():
                output_file.write(f"{word}: {count}\n")
                
        print(f"Umumiy stopwordlar soni: {total_stopwords}")
    
    except FileNotFoundError:
        print(f"Fayl topilmadi: {input_filename}")
    except Exception as e:
        print(f"Xatolik yuz berdi: {str(e)}")


input_filename = r'C:\Bow\input.txt'
output_filename = r'C:\Bow\stopwords_output.txt'
stopwords_filename = r'C:\Bow\stopwordss.txt' 


stopwords = read_stopwords(stopwords_filename)


read_and_process_file(input_filename, output_filename, stopwords)
